const mongoose = require('mongoose');
const data = require('./data.js');

const connectDB = async () => {
    try {
        // mongodb connection string
        const con = await mongoose.connect(`mongodb+srv://fullstack:fullstack@astrum.dfoka.mongodb.net/astrum?retryWrites=true&w=majority`, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            useFindAndModify: false,
            useCreateIndex: true
        })

    } catch (err) {
        // console.error(process.env.DB)
        console.log(err.message);
        process.exit(1);
    }
}

module.exports = connectDB