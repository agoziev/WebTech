const data = {
    admin: process.env.ADMIN,
    password: process.env.PASS,
    db: process.env.DB,
}
module.exports = data