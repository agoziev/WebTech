# User management system

In this project, we are going to create node CRUD application with express and mongodb.

#### To Run this project Clone it and install modules using

```
npm install
```

Then Create config.env file and create PORT and MONGO_URI Variable and specify Value.
That's it. You are ready to go. To execute this project just type

```
npm start
```

Enjoy...!
